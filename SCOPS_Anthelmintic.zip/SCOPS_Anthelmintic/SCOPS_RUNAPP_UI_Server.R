#####################
# Open Source Files #
#####################

source("SCOPS_Load.R")  # Load libraries and data
source("SCOPS_UI-Tabs.R") # UI - Tab functions


##################
# User Interface #
##################

ui <- (fluidPage(theme = shinytheme("united"),

  navbarPage("SCOPS Know Your Anthelmintics",

# About Tab function

   tabPanel("About",
      Aboutp()),

# The SCOPS table

    tabPanel("Wormer Finder",
             DrugFinderp())


)))

##########
# Server #
##########

source("SCOPS_Server-Tabs.R")

server <- (function(input, output, session){
  env_serv = environment()

# About Tab

  Aboutp(env_serv)

# The SCOPS table

  DrugFinderp(env_serv)

})

############
# Load App #
############

shinyApp(ui = ui, server = server)
