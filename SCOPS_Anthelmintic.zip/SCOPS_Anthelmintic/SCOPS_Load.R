#######################
#### Load Packages ####
#######################

library(readr)
library(dplyr)
library(ggplot2)
library(plotly)
library(rsconnect)
library(shinydashboard)
library(shiny)
library(shinythemes)
library(DT)
library(RColorBrewer)

###################
#### Load data ####
###################

SCOPS_Drug <- read_csv("Data/SCOPS_Drug.csv")
Selected <- c("Group", "Label", "Colour", "Product", "Company", "Drug", "Roundworm")
Names <- names(SCOPS_Drug)