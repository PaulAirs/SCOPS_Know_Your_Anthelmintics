# Server Tabs

Aboutp = function(env_serv) with(env_serv, local({
   }))

DrugFinderp = function(env_serv) with(env_serv, local({
   # Check all list for SCOPS drug checkgroupinput
   observe({
      if(input$selectall == 0) return(NULL)
      else if (input$selectall%%2 == 0)
      { updateCheckboxGroupInput(session,"show_vars", "", names(SCOPS_Drug), selected = Selected) }
      else
      { updateCheckboxGroupInput(session,"show_vars", "", names(SCOPS_Drug), selected = names(SCOPS_Drug))}
   })

    output$mytable1 <- DT::renderDataTable({
    DT::datatable(SCOPS_Drug[, input$show_vars, drop = TRUE],
                  filter = 'top',
                  options = list(orderClasses = TRUE,
                                 scrollX=TRUE,
                                 autoWidth = FALSE,
                                 pageLength = 10))
  })
  }))
