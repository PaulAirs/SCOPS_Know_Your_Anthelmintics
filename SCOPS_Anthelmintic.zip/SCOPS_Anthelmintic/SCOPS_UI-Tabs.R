# UI Tabs

# About Tab PAGE

Aboutp = function()
  fluidPage(
  fluidRow(
    div(img(src = "About2.png", height = "338px", width = "600px"),  style="text-align: center;")),
  fluidRow(
    column(12,
           br(),
    div(p("",a("SCOPS", href ="https://www.scops.org.uk/"), 
        "is an industry led group that works in the interest of the UK sheep industry. 
        It recognises that, left unchecked, anthelmintic resistance is one of the biggest challenges 
        to the future health and profitability of the sector. The official guideline pamphlet used can be ", 
        a("found here", href= "https://www.scops.org.uk/workspace/pdfs/anthelmintics-scops-lssc-web-version-2020.pdf"),". Information in this table was last updated in January 2020. For the most up to date information, visit the ",
        a("VMD website", href = "https://www.vmd.defra.gov.uk/ProductInformationDatabase/"),"."),
        p("If you wish to alter data on the site please contact Dr. Paul Airs at P.airs@qub.ac.uk")))))


# The SCOPS drug table

DrugFinderp = function()
      sidebarLayout(
      sidebarPanel(
        width = 2,
        h4("Select columns"),
        actionLink("selectall", "Select All / Reset"),
        checkboxGroupInput("show_vars", "", names(SCOPS_Drug), selected = Selected)),

      mainPanel("",
         width = 10,
         value = "SCOPS_Drug", DT::dataTableOutput("mytable1")))