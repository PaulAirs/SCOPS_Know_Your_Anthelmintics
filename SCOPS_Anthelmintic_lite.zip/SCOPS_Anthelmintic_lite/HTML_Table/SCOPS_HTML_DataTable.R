#######################################################
#### Convert CSV to DataFrame to DataTable to HTML ####
#######################################################

library(tidyverse)
library(DT)
library(readr)

setwd("C:/Users/Paul Airs/Desktop/SCOPS_Anthelmintic_lite/HTML_Table")
SCOPS_Drug1 <- read_csv("SCOPS_Drug1.csv")

### Add URLs from list and add these to product line
#URL <- read_excel("URL.xlsx")
#URL <- paste0("<a href='",URL$URL,"'>",SCOPS_Drug1$Product,"</a>")
#url <- data.frame(URL)

# write out to remove uneeded columns and 
#write.csv(url, "url.csv")

# combine columns, NOT NEEDED since we do this manually to combine both, can keep separate
#SCOPS_Drug <- cbind(SCOPS_Drug1, URL)

# Convert SCOPS_drug table to datatable type
SCOPS_HTML <- datatable(SCOPS_Drug1, rownames= FALSE, escape = FALSE, 
               extensions = 'Responsive', 
               options = list(pageLength = 15, autoWidth = TRUE),
               filter = 'bottom'
               )

COW_HTML <- datatable(COW_Drug, rownames= FALSE, escape = FALSE, 
                      extensions = 'Responsive', 
                      options = list(pageLength = 15, autoWidth = TRUE),
                      filter = 'bottom'
)

# Save datatable as HTML
DT::saveWidget(SCOPS_HTML, 'SCOPS_Sheep.html', selfcontained = TRUE)
DT::saveWidget(COW_HTML, 'SCOPS_cattle.html', selfcontained = TRUE)

####################################################
#### DIFFERENT TABLE TYPE, NO FILTERING THOUGH #####
####################################################

install.packages("rhandsontable")
library(rhandsontable)
DF = data.frame(val = 1:10, bool = TRUE, big = LETTERS[1:10],
                small = letters[1:10],
                dt = seq(from = Sys.Date(), by = "days", length.out = 10),
                stringsAsFactors = FALSE)
rhandsontable(DF, width = 550, height = 300) %>%
  hot_context_menu(allowRowEdit = FALSE, allowColEdit = FALSE)