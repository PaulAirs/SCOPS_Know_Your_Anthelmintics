########
# Load #
########

library(readr)
library(rsconnect)
library(shinydashboard)
library(shiny)
library(shinythemes)
library(DT)

SCOPS_Drug <- read_csv("Data/SCOPS_Drug.csv")
Selected <- c("Group", "Label", "Colour", "Product", "Company", "Drug", "Roundworm")
Names <- names(SCOPS_Drug)

##################
# User Interface #
##################
# The SCOPS drug table

DrugFinderp = function()
  sidebarLayout(
    sidebarPanel(
      width = 2,
      h4("Select columns"),
      actionLink("selectall", "Select All / Reset"),
      checkboxGroupInput("show_vars", "", names(SCOPS_Drug), selected = Selected)),
      #awesomeCheckboxGroup(inputId = "id1", label = "Make a choice:", choices = c("graphics", "ggplot2")),
    mainPanel("",
              width = 10,
              value = "SCOPS_Drug", DT::dataTableOutput("mytable1")))

Aboutp = function()
  fluidPage(
    fluidRow(
      column(12,
             br(),
             div(p("",a("SCOPS", href ="https://www.scops.org.uk/"), 
                   "is an industry led group that works in the interest of the UK sheep industry. 
        It recognises that, left unchecked, anthelmintic resistance is one of the biggest challenges 
        to the future health and profitability of the sector. The official guideline pamphlet used can be ", 
                   a("found here", href= "https://www.scops.org.uk/workspace/pdfs/anthelmintics-scops-lssc-web-version-2020.pdf"),". Information in this table was last updated in January 2020. For the most up to date information, visit the ",
                   a("VMD website", href = "https://www.vmd.defra.gov.uk/ProductInformationDatabase/"),"."),
                 p("If you wish to alter data on the site please contact Dr. Paul Airs at P.airs@qub.ac.uk")))))


ui <- (fluidPage(theme = shinytheme("united"),

  navbarPage("SCOPS Know Your Anthelmintics",


# The SCOPS table

    tabPanel("Wormer Finder",
             DrugFinderp()),

# About Tab function

  tabPanel("About",
         Aboutp())

)))

##########
# Server #
##########

Aboutp = function(env_serv) with(env_serv, local({
}))

DrugFinderp = function(env_serv) with(env_serv, local({
  # Check all list for SCOPS drug checkgroupinput
  observe({
    if(input$selectall == 0) return(NULL)
    else if (input$selectall%%2 == 0)
    { updateCheckboxGroupInput(session,"show_vars", "", names(SCOPS_Drug), selected = Selected) }
    else
    { updateCheckboxGroupInput(session,"show_vars", "", names(SCOPS_Drug), selected = names(SCOPS_Drug))}
  })
  
  output$mytable1 <- DT::renderDataTable({
    DT::datatable(SCOPS_Drug[, input$show_vars, drop = TRUE],
                  filter = 'top',
                  options = list(orderClasses = TRUE,
                                 scrollX=TRUE,
                                 autoWidth = FALSE,
                                 pageLength = 10))
  })
}))

server <- (function(input, output, session){
  env_serv = environment()

# About Tab

  Aboutp(env_serv)

# The SCOPS table

  DrugFinderp(env_serv)

})

############
# Load App #
############

shinyApp(ui = ui, server = server)
